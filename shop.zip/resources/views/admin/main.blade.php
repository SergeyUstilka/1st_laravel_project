@extends('layouts.admin')
@section('adminContent')
    <h1>Main page</h1>
@endsection